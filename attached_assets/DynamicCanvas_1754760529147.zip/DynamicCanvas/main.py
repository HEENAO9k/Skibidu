
from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return '<h1>Python Flask App on Port 3000</h1><p>This is running alongside Node.js on port 5000</p>'

@app.route('/health')
def health():
    return {'status': 'ok', 'port': 3000}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
