# Overview

BetMC Texture Generator Pro is a web-based application that converts video and audio files into Minecraft texture packs. The system features a sophisticated file processing pipeline with real-time progress tracking, YouTube integration for downloading content, and a comprehensive admin panel for system management. It's designed as a user-friendly service that automates the complex process of creating animated texture resources for Minecraft.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Multi-page Structure**: Separate HTML pages for main interface (`index.html`) and admin panel (`admin.html`)
- **Real-time UI Updates**: Socket.IO integration for live progress tracking and system notifications
- **Responsive Design**: CSS Grid and Flexbox with mobile-first approach using glassmorphism design patterns
- **Interactive Elements**: Custom particle system, animated backgrounds, and modal-based workflows
- **Client-side State Management**: JavaScript modules handle file uploads, progress tracking, and configuration updates

## Backend Architecture
- **Express.js Server**: RESTful API with middleware for file handling, authentication, and static content serving
- **Socket.IO Integration**: WebSocket server for real-time communication between client and server
- **File Processing Pipeline**: Multi-stage processing using child processes for video conversion and archive creation
- **Session Management**: Namespace-based session tracking for concurrent user operations
- **Admin Authentication**: bcrypt-based password hashing with role-based access control

## File Management System
- **Multer Integration**: Handles multipart file uploads with configurable storage destinations
- **Directory Structure**: Organized into `uploads/`, `output/`, `zips/`, and `temp/` directories for different file lifecycle stages
- **Automated Cleanup Service**: Cron-based file cleanup with configurable retention policies and disk usage monitoring
- **Archive Generation**: Archiver.js for creating downloadable ZIP packages of processed content

## External Service Integration
- **YouTube Content Processing**: youtube-dl-exec for downloading and processing YouTube videos
- **Email Notifications**: Nodemailer with Gmail SMTP for completion notifications
- **File Processing Tools**: Child process execution for video conversion and manipulation

## Configuration Management
- **JSON-based Config**: Centralized configuration system with runtime updates
- **Feature Toggles**: Enable/disable functionality like uploads, YouTube integration, and email notifications
- **Customizable Theming**: Dynamic color scheme updates with CSS custom properties
- **Admin Controls**: Comprehensive settings for file limits, cleanup policies, and system behavior

# Recent Changes

## August 9, 2025
- **Fixed Application Startup**: Resolved workflow configuration issue where the system was trying to run the Node.js application as a Python Flask app with gunicorn
- **Fixed FFmpeg Dependencies**: Installed ffmpeg and ImageMagick system dependencies, updated server.js to use dynamic binary path detection for Nix environment compatibility
- **Server Status**: BetMC Texture Generator Pro is now running correctly on port 5000 using Node.js with full video processing capabilities
- **Directory Structure**: Confirmed all required directories (uploads, output, zips, temp, config) are present and functional
- **Video Processing**: Fixed "ffmpeg: not found" error by implementing proper binary path resolution

# External Dependencies

## Core Framework Dependencies
- **Express.js 5.1.0**: Web application framework for API and static content serving
- **Socket.IO 4.8.1**: Real-time bidirectional communication between client and server
- **Multer 2.0.2**: Middleware for handling multipart/form-data file uploads

## File Processing Libraries
- **Archiver 7.0.1**: Creates ZIP archives of processed content for download
- **Unzipper 0.12.3**: Extracts and processes uploaded archive files
- **youtube-dl-exec 3.0.23**: Downloads and processes content from YouTube URLs

## Security and Authentication
- **bcrypt 6.0.0**: Password hashing for admin authentication
- **crypto 1.0.1**: Built-in Node.js cryptographic functionality for session management

## Utility Libraries
- **node-cron 4.2.1**: Scheduled task execution for automated file cleanup
- **node-fetch 3.3.2**: HTTP client for external API requests
- **nodemailer 7.0.5**: Email delivery service with SMTP support

## External Services
- **Gmail SMTP**: Email notification delivery service
- **YouTube API**: Content download and metadata extraction (via youtube-dl-exec)
- **File System**: Local storage for uploads, processing, and output files