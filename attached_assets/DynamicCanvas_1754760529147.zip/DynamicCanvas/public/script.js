// Socket connection
const socket = io();

// Global variables
let currentSessionId = null;
let currentConfig = {};

// DOM elements
const uploadForm = document.getElementById('upload-form');
const submitBtn = document.getElementById('submitBtn');
const progressModal = document.getElementById('progressModal');
const successModal = document.getElementById('successModal');
const videoPreview = document.getElementById('videoPreview');
const previewGif = document.getElementById('preview-gif');
const announcementBanner = document.getElementById('announcement-banner');
const announcementText = document.getElementById('announcement-text');
const closeAnnouncement = document.getElementById('close-announcement');
const adminBtn = document.getElementById('admin-btn');

// File inputs
const videoInput = document.getElementById('video');
const audioInput = document.getElementById('audio');
const iconInput = document.getElementById('icon');

// YouTube elements
const youtubeUrl = document.getElementById('youtubeUrl');
const loadYoutube = document.getElementById('loadYoutube');
const youtubePreview = document.getElementById('youtubePreview');
const youtubeSection = document.getElementById('youtube-section');
const uploadSection = document.getElementById('upload-section');

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  initializeApp();
  setupEventListeners();
  initializeParticles();
});

function initializeApp() {
  // Load initial configuration
  socket.on('config-update', (config) => {
    currentConfig = config;
    updateUIFromConfig(config);
  });

  // Handle errors
  socket.on('error', (error) => {
    hideProgress();
    showToast(error.message || 'เกิดข้อผิดพลาด', 'error');
  });

  // Handle progress updates
  socket.on('progress-update', (data) => {
    updateProgress(data.step, data.progress, data.message, data.timeLeft);
  });

  // Handle download ready
  socket.on('download-ready', (data) => {
    showSuccessModal(data.downloadUrl, data.textureName);
  });
}

function setupEventListeners() {
  // Form submission
  uploadForm.addEventListener('submit', handleFormSubmit);

  // File input changes
  videoInput.addEventListener('change', () => handleFileChange(videoInput, 'videoDisplay'));
  audioInput.addEventListener('change', () => handleFileChange(audioInput, 'audioDisplay'));
  iconInput.addEventListener('change', () => handleFileChange(iconInput, 'iconDisplay'));

  // Video preview
  videoInput.addEventListener('change', showVideoPreview);

  // YouTube functionality
  loadYoutube.addEventListener('click', handleYouTubeLoad);
  youtubeUrl.addEventListener('input', validateYouTubeUrl);

  // Modal controls
  document.getElementById('closeSuccess').addEventListener('click', () => {
    successModal.style.display = 'none';
  });

  // Announcement banner
  closeAnnouncement.addEventListener('click', () => {
    announcementBanner.style.display = 'none';
  });

  // Admin access
  adminBtn.addEventListener('click', () => {
    window.open('/admin.html', '_blank');
  });

  // Click outside modal to close
  window.addEventListener('click', (e) => {
    if (e.target === progressModal) {
      // Don't allow closing progress modal
    }
    if (e.target === successModal) {
      successModal.style.display = 'none';
    }
  });
}

function updateUIFromConfig(config) {
  // Update CSS variables
  document.documentElement.style.setProperty('--primary-color', config.primaryColor);
  document.documentElement.style.setProperty('--secondary-color', config.secondaryColor);
  document.documentElement.style.setProperty('--accent-color', config.accentColor);

  // Update GIF
  if (config.gifUrl && previewGif) {
    previewGif.src = config.gifUrl;
  }

  // Show/hide sections based on config
  if (youtubeSection) {
    youtubeSection.style.display = config.youtubeEnabled ? 'block' : 'none';
  }
  if (uploadSection) {
    uploadSection.style.display = config.uploadEnabled ? 'block' : 'none';
  }

  // Show announcement
  if (config.announcement && config.announcement.trim()) {
    announcementText.textContent = config.announcement;
    announcementBanner.style.display = 'block';
  } else {
    announcementBanner.style.display = 'none';
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();

  if (!validateForm()) {
    return;
  }

  const formData = new FormData();
  
  // Add form fields
  const fields = ['textureName', 'email', 'fps', 'quality', 'youtubeQuality'];
  fields.forEach(field => {
    const element = document.getElementById(field);
    if (element && element.value) {
      formData.append(field, element.value);
    }
  });

  // Add YouTube data
  const youtubeVideoId = extractYouTubeId(youtubeUrl.value);
  if (youtubeVideoId) {
    formData.append('youtubeVideoId', youtubeVideoId);
  }

  const useYoutubeAudio = document.getElementById('useYoutubeAudio').checked;
  formData.append('useYoutubeAudio', useYoutubeAudio);

  const youtubeAudioUrl = document.getElementById('youtubeAudioUrl').value;
  const youtubeAudioId = extractYouTubeId(youtubeAudioUrl);
  if (youtubeAudioId) {
    formData.append('youtubeAudioId', youtubeAudioId);
  }

  // Add files
  if (videoInput.files[0]) {
    formData.append('video', videoInput.files[0]);
  }
  if (audioInput.files[0]) {
    formData.append('audio', audioInput.files[0]);
  }
  if (iconInput.files[0]) {
    formData.append('icon', iconInput.files[0]);
  }

  try {
    submitBtn.disabled = true;
    submitBtn.classList.add('loading');

    const response = await fetch('/upload', {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || 'เกิดข้อผิดพลาดในการอัปโหลด');
    }

    currentSessionId = result.sessionId;
    socket.emit('join-progress', currentSessionId);
    showProgress();

  } catch (error) {
    showToast(error.message, 'error');
    submitBtn.disabled = false;
    submitBtn.classList.remove('loading');
  }
}

function validateForm() {
  const hasVideo = videoInput.files.length > 0;
  const hasYouTube = youtubeUrl.value.trim() !== '';

  if (!hasVideo && !hasYouTube) {
    showToast('กรุณาอัปโหลดไฟล์วิดีโอหรือใส่ URL YouTube', 'warning');
    return false;
  }

  if (!currentConfig.uploadEnabled && hasVideo) {
    showToast('ระบบอัปโหลดไฟล์ถูกปิดใช้งานชั่วคราว', 'error');
    return false;
  }

  if (!currentConfig.youtubeEnabled && hasYouTube) {
    showToast('ระบบดาวน์โหลด YouTube ถูกปิดใช้งานชั่วคราว', 'error');
    return false;
  }

  const fps = document.getElementById('fps').value;
  const quality = document.getElementById('quality').value;

  if (fps < 10 || fps > 60) {
    showToast('FPS ต้องอยู่ระหว่าง 10-60', 'warning');
    return false;
  }

  if (quality < 30 || quality > 100) {
    showToast('คุณภาพภาพต้องอยู่ระหว่าง 30-100%', 'warning');
    return false;
  }

  return true;
}

function handleFileChange(input, displayId) {
  const display = document.getElementById(displayId);
  const file = input.files[0];

  if (file) {
    display.classList.add('has-file');
    const uploadText = display.querySelector('.upload-text');
    const uploadHint = display.querySelector('.upload-hint');
    
    uploadText.textContent = file.name;
    uploadHint.textContent = `ขนาด: ${formatFileSize(file.size)}`;
  } else {
    display.classList.remove('has-file');
    resetFileDisplay(displayId);
  }
}

function resetFileDisplay(displayId) {
  const display = document.getElementById(displayId);
  const uploadText = display.querySelector('.upload-text');
  const uploadHint = display.querySelector('.upload-hint');
  
  switch (displayId) {
    case 'videoDisplay':
      uploadText.textContent = 'อัปโหลดไฟล์วิดีโอ';
      uploadHint.textContent = 'MP4, AVI, MOV หรือรูปแบบอื่นๆ';
      break;
    case 'audioDisplay':
      uploadText.textContent = 'อัปโหลดไฟล์เสียง';
      uploadHint.textContent = 'MP3, WAV, OGG หรือรูปแบบอื่นๆ';
      break;
    case 'iconDisplay':
      uploadText.textContent = 'อัปโหลดไอคอน';
      uploadHint.textContent = 'PNG, JPG (แนะนำ 128x128px)';
      break;
  }
}

function showVideoPreview() {
  const file = videoInput.files[0];
  if (!file) {
    videoPreview.style.display = 'none';
    return;
  }

  const video = document.getElementById('previewVideo');
  const fileName = document.getElementById('fileName');
  const duration = document.getElementById('duration');
  const dimensions = document.getElementById('dimensions');

  video.src = URL.createObjectURL(file);
  fileName.textContent = file.name;

  video.onloadedmetadata = () => {
    duration.textContent = formatDuration(video.duration);
    dimensions.textContent = `${video.videoWidth} × ${video.videoHeight}`;
    videoPreview.style.display = 'block';
  };
}

async function handleYouTubeLoad() {
  const url = youtubeUrl.value.trim();
  const videoId = extractYouTubeId(url);

  if (!videoId) {
    showToast('กรุณาใส่ URL YouTube ที่ถูกต้อง', 'warning');
    return;
  }

  if (!currentConfig.youtubeEnabled) {
    showToast('ระบบดาวน์โหลด YouTube ถูกปิดใช้งานชั่วคราว', 'error');
    return;
  }

  try {
    loadYoutube.disabled = true;
    loadYoutube.classList.add('loading');

    // Load YouTube video info (mock for demo)
    const thumbnail = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
    const title = 'YouTube Video'; // In real app, you'd fetch this from YouTube API
    
    document.getElementById('youtubeThumbnail').src = thumbnail;
    document.getElementById('youtubeTitle').textContent = title;
    document.getElementById('youtubeDuration').textContent = 'Loading...';
    
    youtubePreview.style.display = 'block';
    showToast('โหลดวิดีโอ YouTube สำเร็จ', 'success');

  } catch (error) {
    showToast('ไม่สามารถโหลดวิดีโอ YouTube ได้', 'error');
  } finally {
    loadYoutube.disabled = false;
    loadYoutube.classList.remove('loading');
  }
}

function validateYouTubeUrl() {
  const url = youtubeUrl.value.trim();
  const videoId = extractYouTubeId(url);
  
  loadYoutube.disabled = !videoId || !currentConfig.youtubeEnabled;
}

function extractYouTubeId(url) {
  if (!url) return null;
  
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  
  return null;
}

function showProgress() {
  progressModal.style.display = 'block';
  document.body.style.overflow = 'hidden';
  resetProgress();
}

function hideProgress() {
  progressModal.style.display = 'none';
  document.body.style.overflow = '';
  submitBtn.disabled = false;
  submitBtn.classList.remove('loading');
}

function resetProgress() {
  document.getElementById('progressFill').style.width = '0%';
  document.getElementById('progressPercent').textContent = '0%';
  document.getElementById('progressMessage').textContent = 'เริ่มต้นการประมวลผล...';
  document.getElementById('currentStep').textContent = 'ขั้นตอนที่ 1';
  document.getElementById('timeLeft').textContent = '';

  // Reset all steps
  document.querySelectorAll('.step').forEach(step => {
    step.classList.remove('active', 'completed');
  });
}

function updateProgress(step, progress, message, timeLeft) {
  // Update progress bar
  document.getElementById('progressFill').style.width = `${progress}%`;
  document.getElementById('progressPercent').textContent = `${progress}%`;
  document.getElementById('progressMessage').textContent = message;
  document.getElementById('currentStep').textContent = `ขั้นตอนที่ ${step}`;
  
  if (timeLeft) {
    document.getElementById('timeLeft').textContent = `เหลือเวลา: ${timeLeft} วินาที`;
  }

  // Update step indicators
  document.querySelectorAll('.step').forEach((stepEl, index) => {
    const stepNumber = index + 1;
    stepEl.classList.remove('active', 'completed');
    
    if (stepNumber < step) {
      stepEl.classList.add('completed');
    } else if (stepNumber === step) {
      stepEl.classList.add('active');
    }
  });
}

function showSuccessModal(downloadUrl, textureName) {
  hideProgress();
  
  document.getElementById('downloadTextureName').textContent = textureName || 'Texture Pack';
  document.getElementById('downloadBtn').href = downloadUrl;
  
  successModal.style.display = 'block';
  
  // Auto download after 3 seconds
  setTimeout(() => {
    document.getElementById('downloadBtn').click();
  }, 3000);
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  const icon = getToastIcon(type);
  toast.innerHTML = `
    <i class="${icon}"></i>
    <span>${message}</span>
  `;
  
  const container = document.getElementById('toast-container');
  container.appendChild(toast);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    toast.style.animation = 'toastSlideOut 0.3s ease forwards';
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }, 5000);
}

function getToastIcon(type) {
  switch (type) {
    case 'success': return 'fas fa-check-circle';
    case 'error': return 'fas fa-exclamation-circle';
    case 'warning': return 'fas fa-exclamation-triangle';
    default: return 'fas fa-info-circle';
  }
}

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDuration(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Add toast slide out animation
const style = document.createElement('style');
style.textContent = `
  @keyframes toastSlideOut {
    from {
      opacity: 1;
      transform: translateX(0);
    }
    to {
      opacity: 0;
      transform: translateX(100%);
    }
  }
`;
document.head.appendChild(style);
