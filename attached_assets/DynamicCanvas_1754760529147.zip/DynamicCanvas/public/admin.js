// Socket connection
const socket = io();

// Global variables
let isLoggedIn = false;
let adminConfig = {};

// DOM elements
const loginScreen = document.getElementById('login-screen');
const adminPanel = document.getElementById('admin-panel');
const loginForm = document.getElementById('login-form');
const passwordInput = document.getElementById('password');

// Admin controls
const gifUrlInput = document.getElementById('gifUrl');
const gifPreview = document.getElementById('gifPreview');
const updateGifBtn = document.getElementById('updateGif');

const primaryColorInput = document.getElementById('primaryColor');
const secondaryColorInput = document.getElementById('secondaryColor');
const accentColorInput = document.getElementById('accentColor');
const updateColorsBtn = document.getElementById('updateColors');

const uploadToggle = document.getElementById('uploadToggle');
const youtubeToggle = document.getElementById('youtubeToggle');
const uploadStatus = document.getElementById('uploadStatus');
const youtubeStatus = document.getElementById('youtubeStatus');

const announcementInput = document.getElementById('announcement');
const updateAnnouncementBtn = document.getElementById('updateAnnouncement');
const clearAnnouncementBtn = document.getElementById('clearAnnouncement');
const announcementPreview = document.getElementById('announcementPreview');

const newPasswordInput = document.getElementById('newPassword');
const confirmPasswordInput = document.getElementById('confirmPassword');
const changePasswordBtn = document.getElementById('changePassword');

const logoutBtn = document.getElementById('logout-btn');

// Statistics elements
const connectedUsersSpan = document.getElementById('connectedUsers');
const activeProcessesSpan = document.getElementById('activeProcesses');
const totalRequestsSpan = document.getElementById('totalRequests');

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  initializeAdmin();
  setupEventListeners();
  updateStatistics();
});

function initializeAdmin() {
  // Show connection status
  socket.on('connect', () => {
    showToast('เชื่อมต่อสำเร็จ', 'success');
  });

  socket.on('connect_error', () => {
    showToast('ไม่สามารถเชื่อมต่อได้', 'error');
  });

  // Socket event handlers
  socket.on('admin-login-success', () => {
    isLoggedIn = true;
    showAdminPanel();
    showToast('เข้าสู่ระบบสำเร็จ', 'success');
  });

  socket.on('admin-login-failed', (data) => {
    console.log('Login failed:', data); // Debug info
    showToast('รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่', 'error');
    passwordInput.value = '';
    passwordInput.focus();
  });

  socket.on('admin-config', (config) => {
    adminConfig = config;
    updateAdminInterface(config);
  });

  socket.on('config-update', (config) => {
    updatePreviewFromConfig(config);
  });

  socket.on('password-changed', () => {
    showToast('เปลี่ยนรหัสผ่านสำเร็จ', 'success');
    newPasswordInput.value = '';
    confirmPasswordInput.value = '';
  });

  socket.on('password-change-failed', () => {
    showToast('ไม่สามารถเปลี่ยนรหัสผ่านได้', 'error');
  });

  socket.on('disconnect', () => {
    showToast('การเชื่อมต่อขาดหาย', 'warning');
  });

  socket.on('reconnect', () => {
    showToast('เชื่อมต่อใหม่สำเร็จ', 'success');
  });
}

function setupEventListeners() {
  // Login form
  loginForm.addEventListener('submit', handleLogin);

  // GIF management
  updateGifBtn.addEventListener('click', handleGifUpdate);
  gifUrlInput.addEventListener('input', handleGifPreview);

  // Color management
  updateColorsBtn.addEventListener('click', handleColorUpdate);
  primaryColorInput.addEventListener('change', updateColorPreview);
  secondaryColorInput.addEventListener('change', updateColorPreview);
  accentColorInput.addEventListener('change', updateColorPreview);

  // System toggles - Fixed event listeners
  if (uploadToggle) {
    uploadToggle.addEventListener('change', function() {
      handleSystemToggle('upload', uploadToggle.checked);
    });
  }
  
  if (youtubeToggle) {
    youtubeToggle.addEventListener('change', function() {
      handleSystemToggle('youtube', youtubeToggle.checked);
    });
  }

  // Announcements
  updateAnnouncementBtn.addEventListener('click', handleAnnouncementUpdate);
  clearAnnouncementBtn.addEventListener('click', handleAnnouncementClear);
  announcementInput.addEventListener('input', updateAnnouncementPreview);

  // Password change
  changePasswordBtn.addEventListener('click', handlePasswordChange);

  // Logout
  logoutBtn.addEventListener('click', handleLogout);

  // Real-time input updates
  setupRealtimeUpdates();
}

function handleLogin(e) {
  e.preventDefault();

  const password = passwordInput.value.trim();
  if (!password) {
    showToast('กรุณาใส่รหัสผ่าน', 'warning');
    return;
  }

  // Show loading state
  const loginBtn = document.querySelector('.login-btn');
  loginBtn.classList.add('loading');
  loginBtn.disabled = true;

  // Add timeout and retry mechanism
  const loginTimeout = setTimeout(() => {
    showToast('การเชื่อมต่อล้มเหลว กรุณาลองใหม่', 'error');
    loginBtn.classList.remove('loading');
    loginBtn.disabled = false;
  }, 10000);

  socket.emit('admin-login', { password });

  // Clear timeout when we get a response
  const clearLoginTimeout = () => {
    clearTimeout(loginTimeout);
    loginBtn.classList.remove('loading');
    loginBtn.disabled = false;
  };

  socket.once('admin-login-success', clearLoginTimeout);
  socket.once('admin-login-failed', clearLoginTimeout);
}

function showAdminPanel() {
  loginScreen.style.display = 'none';
  adminPanel.style.display = 'block';
  adminPanel.style.animation = 'slideUp 0.8s ease-out';
}

function handleGifUpdate() {
  const gifUrl = gifUrlInput.value.trim();

  if (!gifUrl) {
    showToast('กรุณาใส่ URL ของ GIF', 'warning');
    return;
  }

  if (!isValidUrl(gifUrl)) {
    showToast('URL ไม่ถูกต้อง', 'warning');
    return;
  }

  updateGifBtn.classList.add('loading');

  socket.emit('admin-update-config', { gifUrl });

  setTimeout(() => {
    updateGifBtn.classList.remove('loading');
    showToast('อัปเดต GIF สำเร็จ', 'success');
  }, 1000);
}

function handleGifPreview() {
  const gifUrl = gifUrlInput.value.trim();

  if (gifUrl && isValidUrl(gifUrl)) {
    gifPreview.src = gifUrl;
    gifPreview.style.display = 'block';
    gifPreview.style.animation = 'fadeIn 0.5s ease';
  } else {
    gifPreview.style.display = 'none';
  }
}

function handleColorUpdate() {
  const colors = {
    primaryColor: primaryColorInput.value,
    secondaryColor: secondaryColorInput.value,
    accentColor: accentColorInput.value
  };

  updateColorsBtn.classList.add('loading');

  socket.emit('admin-update-config', colors);

  setTimeout(() => {
    updateColorsBtn.classList.remove('loading');
    showToast('อัปเดตสีสำเร็จ', 'success');
  }, 1000);
}

function updateColorPreview() {
  const primary = primaryColorInput.value;
  const secondary = secondaryColorInput.value;
  const accent = accentColorInput.value;

  // Update CSS variables for preview
  document.documentElement.style.setProperty('--primary-color', primary);
  document.documentElement.style.setProperty('--secondary-color', secondary);
  document.documentElement.style.setProperty('--accent-color', accent);
}

function handleSystemToggle(type, enabled) {
  const config = {};
  
  if (type === 'upload') {
    config.uploadEnabled = enabled;
    showToast(enabled ? 'เปิดใช้งานการอัปโหลดไฟล์แล้ว' : 'ปิดใช้งานการอัปโหลดไฟล์แล้ว', 'success');
  } else if (type === 'youtube') {
    config.youtubeEnabled = enabled;
    showToast(enabled ? 'เปิดใช้งาน YouTube แล้ว' : 'ปิดใช้งาน YouTube แล้ว', 'success');
  }

  socket.emit('admin-update-config', config);
  
  // Update status immediately for better UX
  setTimeout(() => {
    updateSystemStatus();
  }, 100);
}

function updateSystemStatus() {
  if (uploadStatus && uploadToggle) {
    uploadStatus.textContent = uploadToggle.checked ? 'Online' : 'Offline';
    uploadStatus.className = `status-value ${uploadToggle.checked ? 'online' : 'offline'}`;
    
    // Add animation effect
    uploadStatus.style.transform = 'scale(1.1)';
    setTimeout(() => {
      uploadStatus.style.transform = 'scale(1)';
    }, 200);
  }

  if (youtubeStatus && youtubeToggle) {
    youtubeStatus.textContent = youtubeToggle.checked ? 'Online' : 'Offline';
    youtubeStatus.className = `status-value ${youtubeToggle.checked ? 'online' : 'offline'}`;
    
    // Add animation effect
    youtubeStatus.style.transform = 'scale(1.1)';
    setTimeout(() => {
      youtubeStatus.style.transform = 'scale(1)';
    }, 200);
  }
}

function handleAnnouncementUpdate() {
  const announcement = announcementInput.value.trim();

  updateAnnouncementBtn.classList.add('loading');

  socket.emit('admin-update-config', { announcement });

  setTimeout(() => {
    updateAnnouncementBtn.classList.remove('loading');
    showToast('ประกาศสำเร็จ', 'success');
  }, 1000);
}

function handleAnnouncementClear() {
  announcementInput.value = '';
  updateAnnouncementPreview();

  socket.emit('admin-update-config', { announcement: '' });
  showToast('ล้างประกาศแล้ว', 'success');
}

function updateAnnouncementPreview() {
  const text = announcementInput.value.trim();
  announcementPreview.textContent = text || 'No announcement';
  announcementPreview.style.fontStyle = text ? 'normal' : 'italic';
}

function handlePasswordChange() {
  const newPassword = newPasswordInput.value.trim();
  const confirmPassword = confirmPasswordInput.value.trim();

  if (!newPassword || !confirmPassword) {
    showToast('กรุณาใส่รหัสผ่านให้ครบถ้วน', 'warning');
    return;
  }

  if (newPassword !== confirmPassword) {
    showToast('รหัสผ่านไม่ตรงกัน', 'warning');
    return;
  }

  if (newPassword.length < 6) {
    showToast('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร', 'warning');
    return;
  }

  changePasswordBtn.classList.add('loading');

  socket.emit('admin-change-password', { newPassword });

  setTimeout(() => {
    changePasswordBtn.classList.remove('loading');
  }, 2000);
}

function handleLogout() {
  isLoggedIn = false;
  loginScreen.style.display = 'flex';
  adminPanel.style.display = 'none';
  passwordInput.value = '';
  socket.disconnect();
  socket.connect();
  showToast('ออกจากระบบแล้ว', 'success');
}

function updateAdminInterface(config) {
  // Update form values
  gifUrlInput.value = config.gifUrl || '';
  primaryColorInput.value = config.primaryColor || '#667eea';
  secondaryColorInput.value = config.secondaryColor || '#764ba2';
  accentColorInput.value = config.accentColor || '#f093fb';
  uploadToggle.checked = config.uploadEnabled !== false;
  youtubeToggle.checked = config.youtubeEnabled !== false;
  announcementInput.value = config.announcement || '';

  // Update previews
  handleGifPreview();
  updateColorPreview();
  updateSystemStatus();
  updateAnnouncementPreview();
}

function updatePreviewFromConfig(config) {
  // Update color preview
  document.documentElement.style.setProperty('--primary-color', config.primaryColor);
  document.documentElement.style.setProperty('--secondary-color', config.secondaryColor);
  document.documentElement.style.setProperty('--accent-color', config.accentColor);
}

function setupRealtimeUpdates() {
  // Debounced real-time updates for certain inputs
  let colorUpdateTimeout;
  let gifUpdateTimeout;
  let announcementUpdateTimeout;

  [primaryColorInput, secondaryColorInput, accentColorInput].forEach(input => {
    input.addEventListener('change', () => {
      clearTimeout(colorUpdateTimeout);
      colorUpdateTimeout = setTimeout(() => {
        if (isLoggedIn) {
          handleColorUpdate();
        }
      }, 500);
    });
  });

  gifUrlInput.addEventListener('input', () => {
    clearTimeout(gifUpdateTimeout);
    gifUpdateTimeout = setTimeout(() => {
      handleGifPreview();
    }, 300);
  });

  announcementInput.addEventListener('input', () => {
    clearTimeout(announcementUpdateTimeout);
    announcementUpdateTimeout = setTimeout(() => {
      updateAnnouncementPreview();
    }, 200);
  });
}

function updateStatistics() {
  // Mock statistics - in real app, these would come from the server
  let connectedUsers = Math.floor(Math.random() * 50) + 10;
  let activeProcesses = Math.floor(Math.random() * 5);
  let totalRequests = Math.floor(Math.random() * 1000) + 500;

  // Animate counter updates
  animateCounter(connectedUsersSpan, connectedUsers);
  animateCounter(activeProcessesSpan, activeProcesses);
  animateCounter(totalRequestsSpan, totalRequests);

  // Update every 30 seconds
  setTimeout(updateStatistics, 30000);
}

function animateCounter(element, targetValue) {
  const currentValue = parseInt(element.textContent) || 0;
  const increment = Math.ceil((targetValue - currentValue) / 10);

  if (currentValue !== targetValue) {
    element.textContent = Math.max(0, currentValue + increment);
    setTimeout(() => animateCounter(element, targetValue), 100);
  }
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icon = getToastIcon(type);
  toast.innerHTML = `
    <i class="${icon}"></i>
    <span>${message}</span>
  `;

  const container = document.getElementById('toast-container');
  container.appendChild(toast);

  // Auto remove after 5 seconds
  setTimeout(() => {
    toast.style.animation = 'toastSlideOut 0.3s ease forwards';
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }, 5000);
}

function getToastIcon(type) {
  switch (type) {
    case 'success': return 'fas fa-check-circle';
    case 'error': return 'fas fa-exclamation-circle';
    case 'warning': return 'fas fa-exclamation-triangle';
    default: return 'fas fa-info-circle';
  }
}

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

// Add toast slide out animation
const style = document.createElement('style');
style.textContent = `
  @keyframes toastSlideOut {
    from {
      opacity: 1;
      transform: translateX(0);
    }
    to {
      opacity: 0;
      transform: translateX(100%);
    }
  }
`;
document.head.appendChild(style);

// Enhanced visual effects
function addVisualEffects() {
  // Add ripple effect to buttons
  document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;

      ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s linear;
        pointer-events: none;
      `;

      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);

      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });
}

// Add ripple and toggle animation CSS
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
  @keyframes ripple {
    to {
      transform: scale(4);
      opacity: 0;
    }
  }
  
  .status-value {
    transition: all 0.3s ease, transform 0.2s ease;
  }
  
  .toggle-slider {
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  }
  
  .toggle-slider:before {
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  }
`;
document.head.appendChild(rippleStyle);

// Initialize visual effects when DOM is loaded
document.addEventListener('DOMContentLoaded', addVisualEffects);