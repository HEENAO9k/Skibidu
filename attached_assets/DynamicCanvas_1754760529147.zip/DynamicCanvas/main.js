// Entry point for BetMC Texture Generator Pro
const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting BetMC Texture Generator Pro...');

// Start the main server
const server = spawn('node', ['server.js'], {
  stdio: 'inherit',
  cwd: path.resolve(__dirname)
});

server.on('error', (error) => {
  console.error('❌ Failed to start server:', error);
  process.exit(1);
});

server.on('close', (code) => {
  console.log(`🛑 Server process exited with code ${code}`);
  if (code !== 0) {
    process.exit(code);
  }
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('🛑 Shutting down...');
  server.kill('SIGTERM');
  setTimeout(() => {
    server.kill('SIGKILL');
  }, 5000);
});

process.on('SIGTERM', () => {
  console.log('🛑 Terminating...');
  server.kill('SIGTERM');
});