const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const archiver = require('archiver');
const unzipper = require('unzipper');
const crypto = require('crypto');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const nodemailer = require('nodemailer');
const youtubeDl = require('youtube-dl-exec');
const http = require('http');
const socketIo = require('socket.io');
const bcrypt = require('bcrypt');

require('./cleaner');

// Binary path detection for Nix environment
const { execSync: execSyncBase } = require('child_process');

function findBinary(name) {
  try {
    return execSyncBase(`which ${name}`, { encoding: 'utf8' }).trim();
  } catch (error) {
    console.warn(`Warning: ${name} not found in PATH`);
    return name; // fallback to just the name
  }
}

const FFMPEG_PATH = findBinary('ffmpeg');
const MAGICK_PATH = findBinary('magick');

console.log(`🔧 FFmpeg path: ${FFMPEG_PATH}`);
console.log(`🔧 ImageMagick path: ${MAGICK_PATH}`);

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const upload = multer({ dest: 'uploads/' });

// Static files
app.use(express.static('public'));
app.use('/zips', express.static('zips'));
app.use(express.json());

// Admin configuration
let adminConfig = {
  password: '$2b$10$rQj7fXkR8tJmHZkDzxKGfOW8FXGaZzKqJmOqPkYgZnHJKlMnOpQrS', // default: 'man999'
  gifUrl: 'https://media.tenor.com/XQu4UfesS_kAAAAC/minecraft-block.gif',
  primaryColor: '#667eea',
  secondaryColor: '#764ba2',
  accentColor: '#f093fb',
  uploadEnabled: true,
  youtubeEnabled: true,
  announcement: ''
};

// Load admin config
const configPath = './config/admin-config.json';
if (fs.existsSync(configPath)) {
  try {
    adminConfig = { ...adminConfig, ...JSON.parse(fs.readFileSync(configPath, 'utf8')) };
  } catch (error) {
    console.log('Using default admin config');
  }
}

// Save admin config
function saveAdminConfig() {
  try {
    fs.mkdirSync('./config', { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify(adminConfig, null, 2));
  } catch (error) {
    console.error('Failed to save admin config:', error);
  }
}

function generateNamespace() {
  return [...Array(32)].map(() => Math.random().toString(36)[2]).join('');
}

function escapePath(filePath) {
  return `"${filePath.replace(/"/g, '\\"')}"`;
}

const progressClients = new Map();
const adminSessions = new Set();

// Email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || '',
    pass: process.env.EMAIL_PASS || ''
  }
});

async function sendNotificationEmail(email, textureName, downloadUrl) {
  if (!email || !process.env.EMAIL_USER) return;

  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: `🎮 Texture Pack "${textureName}" พร้อมแล้ว!`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4CAF50;">🎉 Texture Pack ของคุณพร้อมแล้ว!</h2>
          <p>สวัสดีครับ!</p>
          <p>Texture Pack "<strong>${textureName}</strong>" ของคุณได้สร้างเสร็จแล้ว</p>
          <div style="text-align: center; margin: 20px 0;">
            <a href="${downloadUrl}" 
               style="background-color: #4CAF50; color: white; padding: 12px 24px; 
                      text-decoration: none; border-radius: 8px; font-weight: bold;">
              📦 ดาวน์โหลดเลย
            </a>
          </div>
          <p style="color: #666; font-size: 12px;">
            หมายเหตุ: ลิงก์นี้จะหมดอายุภายใน 24 ชั่วโมง
          </p>
          <hr>
          <p style="color: #888; font-size: 12px;">
            ขอบคุณที่ใช้บริการ BetMC UI Generator!
          </p>
        </div>
      `
    };

    await transporter.sendMail(mailOptions);
    console.log(`✅ ส่งอีเมลแจ้งเตือนไปยัง ${email} แล้ว`);
  } catch (error) {
    console.error('❌ ไม่สามารถส่งอีเมลได้:', error);
  }
}

// Socket.IO connections
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  // Send current config to new connections
  socket.emit('config-update', {
    gifUrl: adminConfig.gifUrl,
    primaryColor: adminConfig.primaryColor,
    secondaryColor: adminConfig.secondaryColor,
    accentColor: adminConfig.accentColor,
    uploadEnabled: adminConfig.uploadEnabled,
    youtubeEnabled: adminConfig.youtubeEnabled,
    announcement: adminConfig.announcement
  });

  // Admin authentication
  socket.on('admin-login', async (data) => {
    try {
      const isValid = await bcrypt.compare(data.password, adminConfig.password);
      if (isValid) {
        adminSessions.add(socket.id);
        socket.emit('admin-login-success');
        socket.emit('admin-config', adminConfig);
      } else {
        socket.emit('admin-login-failed');
      }
    } catch (error) {
      socket.emit('admin-login-failed');
    }
  });

  // Admin config updates
  socket.on('admin-update-config', (data) => {
    if (!adminSessions.has(socket.id)) return;

    Object.keys(data).forEach(key => {
      if (key !== 'password' && adminConfig.hasOwnProperty(key)) {
        adminConfig[key] = data[key];
      }
    });

    saveAdminConfig();
    
    // Broadcast to all clients
    io.emit('config-update', {
      gifUrl: adminConfig.gifUrl,
      primaryColor: adminConfig.primaryColor,
      secondaryColor: adminConfig.secondaryColor,
      accentColor: adminConfig.accentColor,
      uploadEnabled: adminConfig.uploadEnabled,
      youtubeEnabled: adminConfig.youtubeEnabled,
      announcement: adminConfig.announcement
    });
  });

  // Password change
  socket.on('admin-change-password', async (data) => {
    if (!adminSessions.has(socket.id)) return;

    try {
      const hashedPassword = await bcrypt.hash(data.newPassword, 10);
      adminConfig.password = hashedPassword;
      saveAdminConfig();
      socket.emit('password-changed');
    } catch (error) {
      socket.emit('password-change-failed');
    }
  });

  // Progress tracking
  socket.on('join-progress', (sessionId) => {
    socket.join(`progress-${sessionId}`);
  });

  socket.on('disconnect', () => {
    adminSessions.delete(socket.id);
    console.log('Client disconnected:', socket.id);
  });
});

function sendProgress(sessionId, step, progress, message, timeLeft = null) {
  const data = { step, progress, message, timeLeft };
  io.to(`progress-${sessionId}`).emit('progress-update', data);
}

// YouTube download functions
async function downloadYouTubeVideo(videoId, outputPath, quality = '720') {
  try {
    let format;
    switch (quality) {
      case '480':
        format = 'best[height<=480]';
        break;
      case '720':
        format = 'best[height<=720]';
        break;
      case '1080':
        format = 'best[height<=1080]';
        break;
      default:
        format = 'best[height<=720]';
    }

    await youtubeDl(`https://www.youtube.com/watch?v=${videoId}`, {
      format: format,
      output: outputPath
    });
  } catch (error) {
    throw new Error('ไม่สามารถดาวน์โหลดวิดีโอจาก YouTube ได้');
  }
}

async function downloadYouTubeAudio(videoId, outputPath) {
  try {
    await youtubeDl(`https://www.youtube.com/watch?v=${videoId}`, {
      format: 'bestaudio[ext=m4a]',
      output: outputPath
    });
  } catch (error) {
    throw new Error('ไม่สามารถดาวน์โหลดเสียงจาก YouTube ได้');
  }
}

// Main upload endpoint
app.post('/upload', upload.fields([
  { name: 'video' },
  { name: 'audio' },
  { name: 'icon' }
]), async (req, res) => {
  if (!adminConfig.uploadEnabled && !adminConfig.youtubeEnabled) {
    return res.status(403).json({ error: 'Service temporarily disabled' });
  }

  const sessionId = generateNamespace();

  try {
    const fps = parseFloat(req.body.fps);
    const quality = parseInt(req.body.quality);
    const textureName = req.body.textureName || 'Custom Texture';
    const userEmail = req.body.email;
    const youtubeVideoId = req.body.youtubeVideoId;
    const youtubeQuality = req.body.youtubeQuality || '720';
    const useYoutubeAudio = req.body.useYoutubeAudio === 'true';
    const youtubeAudioId = req.body.youtubeAudioId;

    if (isNaN(fps) || isNaN(quality)) {
      return res.status(400).json({ error: 'Invalid fps or quality value' });
    }

    // Check if YouTube is disabled but YouTube ID provided
    if (!adminConfig.youtubeEnabled && youtubeVideoId) {
      return res.status(403).json({ error: 'YouTube downloads are currently disabled' });
    }

    // Check if upload is disabled but files provided
    if (!adminConfig.uploadEnabled && req.files.video) {
      return res.status(403).json({ error: 'File uploads are currently disabled' });
    }

    res.json({ sessionId });

    const namespace = generateNamespace();
    const outputDir = path.join('output', namespace);
    const frameDir = path.join(outputDir, 'subpacks/1080/betmc_background/betmc_background_frame');
    fs.mkdirSync(frameDir, { recursive: true });

    sendProgress(sessionId, 1, 5, 'เริ่มต้นการประมวลผล...');

    let videoPath;
    let audioPath;

    // YouTube video handling
    if (youtubeVideoId && adminConfig.youtubeEnabled) {
      sendProgress(sessionId, 2, 10, `กำลังดาวน์โหลดวิดีโอจาก YouTube (${youtubeQuality}p)...`);
      const downloadPath = path.join('uploads', `${namespace}_youtube.%(ext)s`);
      await downloadYouTubeVideo(youtubeVideoId, downloadPath, youtubeQuality);
      
      const videoFiles = fs.readdirSync('uploads').filter(f => f.startsWith(`${namespace}_youtube.`));
      if (videoFiles.length === 0) {
        throw new Error('ไม่สามารถดาวน์โหลดวิดีโอจาก YouTube ได้');
      }
      videoPath = path.join('uploads', videoFiles[0]);

      if (useYoutubeAudio) {
        sendProgress(sessionId, 2, 12, 'กำลังดาวน์โหลดเสียงจาก YouTube...');
        const audioDownloadPath = path.join('uploads', `${namespace}_audio.%(ext)s`);
        await downloadYouTubeAudio(youtubeVideoId, audioDownloadPath);
        
        const audioFiles = fs.readdirSync('uploads').filter(f => f.startsWith(`${namespace}_audio.`));
        if (audioFiles.length > 0) {
          audioPath = path.join('uploads', audioFiles[0]);
        }
      }
      
      if (youtubeAudioId) {
        sendProgress(sessionId, 2, 14, 'กำลังดาวน์โหลดเสียงจาก YouTube...');
        const audioDownloadPath = path.join('uploads', `${namespace}_separate_audio.%(ext)s`);
        await downloadYouTubeAudio(youtubeAudioId, audioDownloadPath);
        
        const audioFiles = fs.readdirSync('uploads').filter(f => f.startsWith(`${namespace}_separate_audio.`));
        if (audioFiles.length > 0) {
          audioPath = path.join('uploads', audioFiles[0]);
        }
      }
    } else if (req.files.video && adminConfig.uploadEnabled) {
      videoPath = req.files.video[0].path;
    } else {
      throw new Error('กรุณาอัปโหลดไฟล์วิดีโอหรือใส่ URL YouTube');
    }

    const finalAudioPath = audioPath || (req.files.audio ? req.files.audio[0].path : null);

    sendProgress(sessionId, 3, 15, 'กำลังแยกเฟรมจากวิดีโอ...');
    execSync(`${FFMPEG_PATH} -i ${escapePath(videoPath)} -vf fps=${fps} ${escapePath(path.join(frameDir, 'betmc_img_%d_frame.png'))}`);

    if (youtubeVideoId && fs.existsSync(videoPath)) {
      fs.unlinkSync(videoPath);
    }

    const frames = fs.readdirSync(frameDir).filter(f => f.endsWith('.png'));
    sendProgress(sessionId, 4, 25, `พบ ${frames.length} เฟรม กำลังบีบอัดรูปภาพ...`);

    const totalFrames = frames.length;
    for (let i = 0; i < frames.length; i++) {
      const file = frames[i];
      const input = path.join(frameDir, file);
      const output = path.join(frameDir, `compressed_${file.replace('.png', '.jpg')}`);
      execSync(`${MAGICK_PATH} ${escapePath(input)} -strip -quality ${quality} ${escapePath(output)}`);
      fs.unlinkSync(input);

      const progress = 25 + Math.floor((i + 1) / totalFrames * 25);
      const timeLeft = Math.ceil((totalFrames - i - 1) * 0.5);
      sendProgress(sessionId, 4, progress, `บีบอัดเฟรม ${i + 1}/${totalFrames}`, timeLeft);
    }

    sendProgress(sessionId, 5, 50, 'จัดระเบียบไฟล์...');
    fs.readdirSync(frameDir).forEach(file => {
      if (file.startsWith('compressed_')) {
        fs.renameSync(
          path.join(frameDir, file),
          path.join(frameDir, file.replace('compressed_', ''))
        );
      }
    });

    const frame60 = path.join(frameDir, 'betmc_img_60_frame.jpg');
    const staticPatch = path.join(outputDir, 'subpacks/0/betmc_background/betmc_background_static_patch.jpg');
    fs.mkdirSync(path.dirname(staticPatch), { recursive: true });
    if (fs.existsSync(frame60)) {
      fs.copyFileSync(frame60, staticPatch);
    }

    sendProgress(sessionId, 6, 55, 'ดาวน์โหลด manifest.json...');
    const manifestUrl = req.body.manifestUrl || 'https://raw.githubusercontent.com/HEENAO9k/Sounds/main/manifest.json';
    const manifestResponse = await fetch(manifestUrl);
    if (!manifestResponse.ok) throw new Error(`Failed to fetch manifest.json from ${manifestUrl}`);
    const manifestText = await manifestResponse.text();
    const manifest = JSON.parse(manifestText);

    manifest.header.name = textureName;
    manifest.header.uuid = crypto.randomUUID();
    manifest.modules[0].uuid = crypto.randomUUID();

    const manifestPath = path.join(outputDir, 'manifest.json');
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

    sendProgress(sessionId, 7, 60, 'ดาวน์โหลดไฟล์เสียง...');
    const soundsZipUrl = req.body.soundsZipUrl || 'https://github.com/HEENAO9k/Sounds/raw/main/sounds.zip';
    const soundsResponse = await fetch(soundsZipUrl);
    if (!soundsResponse.ok) throw new Error(`Failed to fetch sounds.zip from ${soundsZipUrl}`);

    const soundsZipPath = path.join('uploads', `${namespace}_sounds.zip`);
    const soundsZipStream = fs.createWriteStream(soundsZipPath);
    await new Promise((resolve, reject) => {
      soundsResponse.body.pipe(soundsZipStream);
      soundsResponse.body.on('error', reject);
      soundsZipStream.on('finish', resolve);
    });

    sendProgress(sessionId, 8, 65, 'แตกไฟล์เสียง...');
    await fs.createReadStream(soundsZipPath)
      .pipe(unzipper.Extract({ path: path.join(outputDir, 'sounds') }))
      .promise();

    fs.unlinkSync(soundsZipPath);

    if (finalAudioPath) {
      sendProgress(sessionId, 9, 70, 'เพิ่มไฟล์เสียงที่อัปโหลด...');
      const audioDestination = path.join(outputDir, 'sounds/music/game/creative/creative1.ogg');
      fs.mkdirSync(path.dirname(audioDestination), { recursive: true });
      execSync(`${FFMPEG_PATH} -i ${escapePath(finalAudioPath)} -c:a libvorbis ${escapePath(audioDestination)}`);
      
      if (finalAudioPath.includes('_audio.') || finalAudioPath.includes('_separate_audio.')) {
        fs.unlinkSync(finalAudioPath);
      }
    }

    if (req.files.icon) {
      sendProgress(sessionId, 10, 75, 'เพิ่มไอคอน...');
      const iconPath = path.join(outputDir, 'pack_icon.png');
      execSync(`${MAGICK_PATH} ${escapePath(req.files.icon[0].path)} -resize 128x128 ${escapePath(iconPath)}`);
    }

    sendProgress(sessionId, 11, 80, 'สร้างไฟล์ ZIP...');
    const zipPath = path.join('zips', `${namespace}.zip`);
    fs.mkdirSync('zips', { recursive: true });

    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });

      output.on('close', resolve);
      archive.on('error', reject);

      archive.pipe(output);
      archive.directory(outputDir, false);
      archive.finalize();
    });

    sendProgress(sessionId, 12, 95, 'ล้างไฟล์ชั่วคราว...');
    fs.rmSync(outputDir, { recursive: true, force: true });

    const downloadUrl = `${req.protocol}://${req.get('host')}/zips/${namespace}.zip`;
    
    if (userEmail) {
      await sendNotificationEmail(userEmail, textureName, downloadUrl);
    }

    sendProgress(sessionId, 13, 100, 'เสร็จสิ้น!');
    
    setTimeout(() => {
      io.to(`progress-${sessionId}`).emit('download-ready', {
        downloadUrl,
        textureName,
        namespace
      });
    }, 1000);

  } catch (error) {
    console.error('Error during processing:', error);
    io.to(`progress-${sessionId}`).emit('error', {
      message: error.message || 'เกิดข้อผิดพลาดในการประมวลผล'
    });
  }
});

// API endpoints
app.get('/api/config', (req, res) => {
  res.json({
    gifUrl: adminConfig.gifUrl,
    primaryColor: adminConfig.primaryColor,
    secondaryColor: adminConfig.secondaryColor,
    accentColor: adminConfig.accentColor,
    uploadEnabled: adminConfig.uploadEnabled,
    youtubeEnabled: adminConfig.youtubeEnabled,
    announcement: adminConfig.announcement
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
